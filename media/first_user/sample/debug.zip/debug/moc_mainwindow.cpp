/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../MgaMatrix12/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[38];
    char stringdata0[803];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 10), // "newProject"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 18), // "storeButtonClicked"
QT_MOC_LITERAL(4, 42, 24), // "inputCameraButtonClicked"
QT_MOC_LITERAL(5, 67, 23), // "numericAddButtonClicked"
QT_MOC_LITERAL(6, 91, 31), // "numericSubtractionButtonClicked"
QT_MOC_LITERAL(7, 123, 16), // "addButtonClicked"
QT_MOC_LITERAL(8, 140, 21), // "inverseButtonReleased"
QT_MOC_LITERAL(9, 162, 25), // "subtractionButtonReleased"
QT_MOC_LITERAL(10, 188, 22), // "multiplyButtonReleased"
QT_MOC_LITERAL(11, 211, 16), // "treeView_clicked"
QT_MOC_LITERAL(12, 228, 5), // "index"
QT_MOC_LITERAL(13, 234, 34), // "treeWidget_functions_doubleCl..."
QT_MOC_LITERAL(14, 269, 25), // "funcRunAllButton_released"
QT_MOC_LITERAL(15, 295, 19), // "new4dButtonReleased"
QT_MOC_LITERAL(16, 315, 19), // "new3dButtonReleased"
QT_MOC_LITERAL(17, 335, 19), // "new2dButtonReleased"
QT_MOC_LITERAL(18, 355, 22), // "newCvMatButtonReleased"
QT_MOC_LITERAL(19, 378, 22), // "newGroupButtonReleased"
QT_MOC_LITERAL(20, 401, 25), // "convolutionButtonReleased"
QT_MOC_LITERAL(21, 427, 23), // "thresholdButtonReleased"
QT_MOC_LITERAL(22, 451, 23), // "grayscaleButtonReleased"
QT_MOC_LITERAL(23, 475, 31), // "scalarMatrixMultiButtonReleased"
QT_MOC_LITERAL(24, 507, 26), // "extendMatrixButtonReleased"
QT_MOC_LITERAL(25, 534, 19), // "inputButtonReleased"
QT_MOC_LITERAL(26, 554, 24), // "decimationButtonReleased"
QT_MOC_LITERAL(27, 579, 22), // "treeView_doubleClicked"
QT_MOC_LITERAL(28, 602, 21), // "treeViewCvMat_clicked"
QT_MOC_LITERAL(29, 624, 27), // "treeViewCvMat_doubleClicked"
QT_MOC_LITERAL(30, 652, 25), // "funcDeleteButton_released"
QT_MOC_LITERAL(31, 678, 28), // "tensorsDeleteButton_released"
QT_MOC_LITERAL(32, 707, 23), // "viewImageButtonReleased"
QT_MOC_LITERAL(33, 731, 5), // "about"
QT_MOC_LITERAL(34, 737, 11), // "updateMenus"
QT_MOC_LITERAL(35, 749, 13), // "createProject"
QT_MOC_LITERAL(36, 763, 17), // "MgaMatrixProject*"
QT_MOC_LITERAL(37, 781, 21) // "switchLayoutDirection"

    },
    "MainWindow\0newProject\0\0storeButtonClicked\0"
    "inputCameraButtonClicked\0"
    "numericAddButtonClicked\0"
    "numericSubtractionButtonClicked\0"
    "addButtonClicked\0inverseButtonReleased\0"
    "subtractionButtonReleased\0"
    "multiplyButtonReleased\0treeView_clicked\0"
    "index\0treeWidget_functions_doubleClicked\0"
    "funcRunAllButton_released\0new4dButtonReleased\0"
    "new3dButtonReleased\0new2dButtonReleased\0"
    "newCvMatButtonReleased\0newGroupButtonReleased\0"
    "convolutionButtonReleased\0"
    "thresholdButtonReleased\0grayscaleButtonReleased\0"
    "scalarMatrixMultiButtonReleased\0"
    "extendMatrixButtonReleased\0"
    "inputButtonReleased\0decimationButtonReleased\0"
    "treeView_doubleClicked\0treeViewCvMat_clicked\0"
    "treeViewCvMat_doubleClicked\0"
    "funcDeleteButton_released\0"
    "tensorsDeleteButton_released\0"
    "viewImageButtonReleased\0about\0updateMenus\0"
    "createProject\0MgaMatrixProject*\0"
    "switchLayoutDirection"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      34,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  184,    2, 0x08 /* Private */,
       3,    0,  185,    2, 0x08 /* Private */,
       4,    0,  186,    2, 0x08 /* Private */,
       5,    0,  187,    2, 0x08 /* Private */,
       6,    0,  188,    2, 0x08 /* Private */,
       7,    0,  189,    2, 0x08 /* Private */,
       8,    0,  190,    2, 0x08 /* Private */,
       9,    0,  191,    2, 0x08 /* Private */,
      10,    0,  192,    2, 0x08 /* Private */,
      11,    1,  193,    2, 0x08 /* Private */,
      13,    1,  196,    2, 0x08 /* Private */,
      14,    0,  199,    2, 0x08 /* Private */,
      15,    0,  200,    2, 0x08 /* Private */,
      16,    0,  201,    2, 0x08 /* Private */,
      17,    0,  202,    2, 0x08 /* Private */,
      18,    0,  203,    2, 0x08 /* Private */,
      19,    0,  204,    2, 0x08 /* Private */,
      20,    0,  205,    2, 0x08 /* Private */,
      21,    0,  206,    2, 0x08 /* Private */,
      22,    0,  207,    2, 0x08 /* Private */,
      23,    0,  208,    2, 0x08 /* Private */,
      24,    0,  209,    2, 0x08 /* Private */,
      25,    0,  210,    2, 0x08 /* Private */,
      26,    0,  211,    2, 0x08 /* Private */,
      27,    1,  212,    2, 0x08 /* Private */,
      28,    1,  215,    2, 0x08 /* Private */,
      29,    1,  218,    2, 0x08 /* Private */,
      30,    0,  221,    2, 0x08 /* Private */,
      31,    0,  222,    2, 0x08 /* Private */,
      32,    0,  223,    2, 0x08 /* Private */,
      33,    0,  224,    2, 0x08 /* Private */,
      34,    0,  225,    2, 0x08 /* Private */,
      35,    0,  226,    2, 0x08 /* Private */,
      37,    0,  227,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QModelIndex,   12,
    QMetaType::Void, QMetaType::QModelIndex,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QModelIndex,   12,
    QMetaType::Void, QMetaType::QModelIndex,   12,
    QMetaType::Void, QMetaType::QModelIndex,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 36,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->newProject(); break;
        case 1: _t->storeButtonClicked(); break;
        case 2: _t->inputCameraButtonClicked(); break;
        case 3: _t->numericAddButtonClicked(); break;
        case 4: _t->numericSubtractionButtonClicked(); break;
        case 5: _t->addButtonClicked(); break;
        case 6: _t->inverseButtonReleased(); break;
        case 7: _t->subtractionButtonReleased(); break;
        case 8: _t->multiplyButtonReleased(); break;
        case 9: _t->treeView_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 10: _t->treeWidget_functions_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 11: _t->funcRunAllButton_released(); break;
        case 12: _t->new4dButtonReleased(); break;
        case 13: _t->new3dButtonReleased(); break;
        case 14: _t->new2dButtonReleased(); break;
        case 15: _t->newCvMatButtonReleased(); break;
        case 16: _t->newGroupButtonReleased(); break;
        case 17: _t->convolutionButtonReleased(); break;
        case 18: _t->thresholdButtonReleased(); break;
        case 19: _t->grayscaleButtonReleased(); break;
        case 20: _t->scalarMatrixMultiButtonReleased(); break;
        case 21: _t->extendMatrixButtonReleased(); break;
        case 22: _t->inputButtonReleased(); break;
        case 23: _t->decimationButtonReleased(); break;
        case 24: _t->treeView_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 25: _t->treeViewCvMat_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 26: _t->treeViewCvMat_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 27: _t->funcDeleteButton_released(); break;
        case 28: _t->tensorsDeleteButton_released(); break;
        case 29: _t->viewImageButtonReleased(); break;
        case 30: _t->about(); break;
        case 31: _t->updateMenus(); break;
        case 32: { MgaMatrixProject* _r = _t->createProject();
            if (_a[0]) *reinterpret_cast< MgaMatrixProject**>(_a[0]) = _r; }  break;
        case 33: _t->switchLayoutDirection(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 34)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 34;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 34)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 34;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
